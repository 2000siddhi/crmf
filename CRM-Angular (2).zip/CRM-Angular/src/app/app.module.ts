import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ResourceListComponent } from './resource-list/resource-list.component';
import { ResourceEnquiryFormComponent } from './resource-enquiry-form/resource-enquiry-form.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseEnquiryFormComponent } from './course-enquiry-form/course-enquiry-form.component';



@NgModule({
  declarations: [
    AppComponent,
    ResourceListComponent,
    ResourceEnquiryFormComponent,
    CourseListComponent,
    CourseEnquiryFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
