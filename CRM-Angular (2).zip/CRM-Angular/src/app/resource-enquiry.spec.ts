import { ResourceEnquiry } from './resource-enquiry';

describe('ResourceEnquiry', () => {
  it('should create an instance', () => {
    expect(new ResourceEnquiry()).toBeTruthy();
  });
});
