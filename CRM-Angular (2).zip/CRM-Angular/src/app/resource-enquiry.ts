export class ResourceEnquiry {
    

}
