import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  url="./assets/lab-computer.jpg"
  url2="./assets/full-stack-developer-2.jpg"
  url3="./assets/Python.png"
  url4="./assets/ML.png"
}
