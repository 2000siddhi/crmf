import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-enquiry-form',
  templateUrl: './course-enquiry-form.component.html',
  styleUrls: ['./course-enquiry-form.component.css']
})
export class CourseEnquiryFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
