import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseEnquiryFormComponent } from './course-enquiry-form.component';

describe('CourseEnquiryFormComponent', () => {
  let component: CourseEnquiryFormComponent;
  let fixture: ComponentFixture<CourseEnquiryFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CourseEnquiryFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseEnquiryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
