import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-resource-list',
  templateUrl: './resource-list.component.html',
  styleUrls: ['./resource-list.component.css']
})
export class ResourceListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  url="./assets/lab-computer.jpg"
  url2="./assets/classroom.jpg"


}
