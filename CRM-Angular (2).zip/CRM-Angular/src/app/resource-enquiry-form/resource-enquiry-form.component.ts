import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-enquiry-form',
  templateUrl: './resource-enquiry-form.component.html',
  styleUrls: ['./resource-enquiry-form.component.css']
})
export class ResourceEnquiryFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
