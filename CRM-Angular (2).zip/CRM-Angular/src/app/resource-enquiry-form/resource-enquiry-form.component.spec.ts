import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceEnquiryFormComponent } from './resource-enquiry-form.component';

describe('ResourceEnquiryFormComponent', () => {
  let component: ResourceEnquiryFormComponent;
  let fixture: ComponentFixture<ResourceEnquiryFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResourceEnquiryFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourceEnquiryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
